=========================
Mediation Adapter Headers
=========================

These header files are used to create third party mediation adapters and are not
required to display ads in your application.
